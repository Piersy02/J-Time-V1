package it.unicam.cs.mpgc.jtime119159.model;

public enum ProjectStatus {
    ACTIVE,
    COMPLETED,
    ARCHIVED
}
